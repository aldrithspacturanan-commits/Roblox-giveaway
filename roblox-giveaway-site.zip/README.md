# Roblox Giveaway — Website Prototype

This is a mobile-friendly, static website prototype with:
- Dark Roblox-inspired styling
- Public Roblox username lookup using Roblox's public user API
- Sample giveaway event cards
- Mobile navigation and safety rules

## Test on your Android phone
1. Extract `roblox-giveaway-site.zip`.
2. Open `index.html` in a browser. Depending on your browser, the username lookup may be blocked when opened directly as a local file. If so, use the hosting steps below.
3. Try searching a public Roblox username.

## Publish free (GitHub Pages)
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example `roblox-giveaway`.
3. Upload `index.html`, `style.css`, and `app.js` to the repository root.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait for GitHub to publish the site; the Pages section will show the exact public URL.
7. Optional: submit the public URL to Google Search Console to request indexing. Search visibility is not instant or guaranteed.

## Before publishing
- Replace sample giveaway text with accurate details and rules.
- Never ask visitors for Roblox passwords, verification codes, or browser cookies.
- Do not imply a prize is guaranteed unless you can actually provide it.
- This is a fan-made site and is not affiliated with Roblox Corporation.
- The username lookup depends on Roblox's public API and internet connectivity. Third-party API availability can change.
- The website does not distribute Robux, process payments, or run an actual giveaway.
