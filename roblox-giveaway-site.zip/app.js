const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
$("menuBtn").addEventListener("click", () => $("nav").classList.toggle("open"));
$("nav").querySelectorAll("a").forEach(a => a.addEventListener("click", () => $("nav").classList.remove("open")));

$("searchForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = $("username").value.trim();
  if (!username) return;
  $("searchBtn").disabled = true;
  $("searchBtn").textContent = "Searching…";
  $("searchStatus").textContent = "Looking up public Roblox profile…";
  $("profileResult").innerHTML = "";
  try {
    const response = await fetch("https://users.roblox.com/v1/usernames/users", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({usernames:[username], excludeBannedUsers:false})
    });
    if (!response.ok) throw new Error("Roblox lookup is temporarily unavailable. Try again later.");
    const data = await response.json();
    if (!data.data || data.data.length === 0) {
      $("searchStatus").textContent = "No public account found for that username. Check the spelling and try again.";
      return;
    }
    const user = data.data[0];
    let avatar = "";
    try {
      const avatarResponse = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${user.id}&size=150x150&format=Png&isCircular=false`);
      if (avatarResponse.ok) {
        const avatarData = await avatarResponse.json();
        avatar = avatarData.data?.[0]?.imageUrl || "";
      }
    } catch (_) {}
    const profile = document.createElement("div");
    profile.className = "profile";
    const img = document.createElement("img");
    img.className = "avatar";
    img.alt = "Roblox avatar";
    img.src = avatar;
    const details = document.createElement("div");
    const title = document.createElement("h3");
    title.textContent = user.displayName || user.name;
    const handle = document.createElement("p");
    handle.textContent = "@" + user.name + " · User ID " + user.id;
    const link = document.createElement("a");
    link.href = `https://www.roblox.com/users/${user.id}/profile`;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "Open Roblox profile ↗";
    details.append(title, handle, link);
    profile.append(img, details);
    $("profileResult").append(profile);
    $("searchStatus").textContent = "Public profile found.";
  } catch (err) {
    $("searchStatus").textContent = err.message || "Could not complete lookup. Check your internet connection.";
  } finally {
    $("searchBtn").disabled = false;
    $("searchBtn").innerHTML = 'Search <span>⌕</span>';
  }
});

document.querySelectorAll("[data-event]").forEach(button => button.addEventListener("click", () => {
  const box = $("eventDetails");
  box.hidden = false;
  box.textContent = `${button.dataset.event}: This is sample content for your prototype. Add the real prize, host, start/end dates, eligibility rules, and winner-selection method before publishing. No prize is awarded by this demo.`;
  box.scrollIntoView({behavior:"smooth", block:"nearest"});
}));
